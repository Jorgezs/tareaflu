import 'package:flutter/material.dart';

class Pagina1 extends StatefulWidget {
  const Pagina1({
    Key key,
  }) : super(key: key);

  @override
  State<Pagina1> createState() => _Pagina1State();
}

class _Pagina1State extends State<Pagina1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: cuerpo2(context),
    );
  }
}

Widget name1() {
  return Text(
    "Recuperar contraseña",
    style: TextStyle(color: Colors.white, fontSize: 30),
  );
}

Widget campoTexto1() {
  return Container(
    padding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
    child: TextField(
      decoration: InputDecoration(
        hintText: "Correo",
        fillColor: Colors.white,
        filled: true,
      ),
    ),
  );
}

Widget botom1(context) {
  return MaterialButton(
    onPressed: () {
      Navigator.pop(context);
    },
    child: Text("Volver", style: TextStyle(color: Colors.white, fontSize: 20)),
    color: Colors.blue,
  );
}

Widget cuerpo2(context) {
  return Container(
    decoration: BoxDecoration(
      image: DecorationImage(
          image: NetworkImage(
              "https://4.bp.blogspot.com/-8k9Oaa_RrC0/Us9IKW4hfiI/AAAAAAAAIG0/WMrVafkCwPk/s1600/89262_1600x1200.jpg"),
          fit: BoxFit.cover),
    ),
    child: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          name1(),
          SizedBox(
            height: 30,
          ),
          campoTexto1(),
          SizedBox(
            height: 20,
          ),
          botom1(context),
        ],
      ),
    ),
  );
}
