import 'package:flutter/material.dart';

class Registro extends StatefulWidget {
  const Registro({
    Key key,
  }) : super(key: key);

  @override
  State<Registro> createState() => _RegistroState();
}

class _RegistroState extends State<Registro> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Inicio"),
      ),
      body: cuerpo3(context),
    );
  }
}

Widget name2() {
  return Text(
    "Registros",
    style: TextStyle(color: Colors.white, fontSize: 30),
  );
}

Widget campoTexto2() {
  return DataTable(
    decoration: BoxDecoration(color: Colors.white),
    border: TableBorder.all(
      width: 2.0,
      color: Colors.black,
    ),
    columns: [
      DataColumn(label: Text("Fecha")),
      DataColumn(label: Text("Inicio")),
      DataColumn(label: Text("Retardo")),
    ],
    rows: [
      DataRow(
        cells: [
          DataCell(Text("     25-12-2023     ")),
          DataCell(Text("     12:12    ")),
          DataCell(Text("     17:12")),
        ],
      ),
      DataRow(
        cells: [
          DataCell(Text("      10-08-2023")),
          DataCell(Text("     13:50")),
          DataCell(Text("     20:36")),
        ],
      ),
    ],
  );
}

Widget botom2(context) {
  return MaterialButton(
    onPressed: () {
      Navigator.pop(context);
    },
    child: Text("Volver", style: TextStyle(color: Colors.white, fontSize: 20)),
    color: Colors.blue,
  );
}

Widget cuerpo3(context) {
  return Container(
    decoration: BoxDecoration(
      image: DecorationImage(
          image: NetworkImage(
              "https://4.bp.blogspot.com/-8k9Oaa_RrC0/Us9IKW4hfiI/AAAAAAAAIG0/WMrVafkCwPk/s1600/89262_1600x1200.jpg"),
          fit: BoxFit.cover),
    ),
    child: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[
          name2(),
          campoTexto2(),
          botom2(context),
        ],
      ),
    ),
  );
}
