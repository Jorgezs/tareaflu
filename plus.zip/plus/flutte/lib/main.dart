import 'package:flutter/material.dart';
import 'package:flutte/pages/pagina.dart';
import 'package:flutte/login/iniciio.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: "Login",
        initialRoute: "Login",
        routes: <String, WidgetBuilder>{
          "Login": (BuildContext context) => Inicio(),
          "Recuperar": (BuildContext context) => Pagina1(),
          "Tablas": (BuildContext context) => Registro(),
        });
  }
}

class Inicio extends StatefulWidget {
  const Inicio({
    Key key,
  }) : super(key: key);

  @override
  State<Inicio> createState() => _InicioState();
}

class _InicioState extends State<Inicio> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: cuerpo(context),
    );
  }
}

Widget cuerpo(context) {
  return Container(
    decoration: BoxDecoration(
      image: DecorationImage(
          image: NetworkImage(
              "https://4.bp.blogspot.com/-8k9Oaa_RrC0/Us9IKW4hfiI/AAAAAAAAIG0/WMrVafkCwPk/s1600/89262_1600x1200.jpg"),
          fit: BoxFit.cover),
    ),
    child: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          imagen(),
          name(),
          campoTexto(),
          campoContrasena(),
          SizedBox(
            height: 20,
          ),
          botom(context),
          SizedBox(
            height: 20,
          ),
          botom1_1(context),
        ],
      ),
    ),
  );
}

Widget imagen() {
  return Image(
    width: 200,
    height: 200,
    image: NetworkImage(
        "https://tse1.mm.bing.net/th?id=OIP.ZFt9tG9gFQuIPN6b3jP6cQHaHa&pid=Api&P=0"),
  );
}

Widget name() {
  return Text(
    "Iniciar Sesion",
    style: TextStyle(color: Colors.white, fontSize: 50),
  );
}

Widget campoTexto() {
  return Container(
    padding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
    child: TextField(
      decoration: InputDecoration(
        hintText: "Usuario",
        fillColor: Colors.white,
        filled: true,
      ),
    ),
  );
}

Widget campoContrasena() {
  return Container(
    padding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
    child: TextField(
      obscureText: true,
      decoration: InputDecoration(
        hintText: "Password",
        fillColor: Colors.white,
        filled: true,
      ),
    ),
  );
}

Widget botom(context) {
  return MaterialButton(
    onPressed: () {
      final route = MaterialPageRoute(
        builder: (context) => Registro(),
      );
      Navigator.push(context, route);
    },
    child: Text("Iniciar Sesion",
        style: TextStyle(color: Colors.white, fontSize: 20)),
    color: Colors.blue,
  );
}

Widget botom1_1(context) {
  return MaterialButton(
    onPressed: () {
      final route = MaterialPageRoute(
        builder: (context) => Pagina1(),
      );
      Navigator.push(context, route);
    },
    child: Text("¿Olvidaste tu contraseña?",
        style: TextStyle(color: Colors.blue, fontSize: 15)),
  );
}
